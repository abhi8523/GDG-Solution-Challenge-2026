/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  Thermometer, 
  Wind, 
  Activity, 
  MapPin, 
  ArrowRight, 
  ShieldAlert, 
  CheckCircle2,
  Bell,
  Cpu,
  RefreshCw,
  LogOut
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { GoogleGenAI, Type } from "@google/genai";

// --- Types ---

interface SensorNode {
  id: string;
  name: string;
  location: string;
  temp: number;
  smoke: 'None' | 'Low' | 'Detected';
  gas: number; // ppm
}

interface AIResponse {
  isEmergency: boolean;
  type: string;
  affectedArea: string;
  severity: 'Low' | 'Medium' | 'High' | 'Normal';
  evacuationRoute: string;
  alertMessage: string;
}

// --- Initial Data ---

const INITIAL_NODES: SensorNode[] = [
  { id: 'N1', name: 'Node 1', location: 'Room A', temp: 70, smoke: 'Detected', gas: 250 },
  { id: 'N2', name: 'Node 2', location: 'Room B', temp: 60, smoke: 'Detected', gas: 200 },
  { id: 'N3', name: 'Node 3', location: 'Corridor C', temp: 35, smoke: 'Low', gas: 45 },
];

export default function App() {
  const [nodes, setNodes] = useState<SensorNode[]>(INITIAL_NODES);
  const [analysis, setAnalysis] = useState<AIResponse | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string>(new Date().toLocaleTimeString());

  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

  const analyzeEmergency = async () => {
    setIsAnalyzing(true);
    try {
      const sensorDataString = nodes.map(n => 
        `Node ${n.id} (${n.location}): Temp ${n.temp}°C, Smoke ${n.smoke}, Gas ${n.gas} ppm`
      ).join('\n');

      const prompt = `
        Analyze the following smart building sensor data and determine the emergency status:
        
        SENSOR DATA:
        ${sensorDataString}
        
        NEARBY LOCATIONS:
        Exit D (safe), Corridor C (partially affected), Room A (high risk)
        
        TASKS:
        1. Determine whether this is a real emergency or a false alarm.
        2. Identify the type of emergency and affected area.
        3. Assess severity level (Low / Medium / High).
        4. Suggest the safest evacuation route.
        5. Generate a short, clear, human-friendly emergency alert message.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              isEmergency: { type: Type.BOOLEAN },
              type: { type: Type.STRING },
              affectedArea: { type: Type.STRING },
              severity: { 
                type: Type.STRING,
                enum: ["Low", "Medium", "High", "Normal"]
              },
              evacuationRoute: { type: Type.STRING },
              alertMessage: { type: Type.STRING },
            },
            required: ["isEmergency", "type", "affectedArea", "severity", "evacuationRoute", "alertMessage"],
          },
        },
      });

      if (response.text) {
        setAnalysis(JSON.parse(response.text));
      }
    } catch (error) {
      console.error('AI Analysis failed:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'High': return 'text-red-500 bg-red-500/10 border-red-500/20';
      case 'Medium': return 'text-amber-500 bg-amber-500/10 border-amber-500/20';
      case 'Low': return 'text-blue-500 bg-blue-500/10 border-blue-500/20';
      default: return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20';
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-[#E4E4E7] font-sans selection:bg-red-500/30">
      {/* Background Grid Pattern */}
      <div className="fixed inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />
      <div className="fixed inset-0 bg-radial-[circle_800px_at_100%_200px,#3b0707,transparent] pointer-events-none" />

      {/* Header */}
      <header className="relative z-10 border-b border-white/10 bg-black/40 backdrop-blur-md px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-red-500/10 rounded-lg border border-red-500/20">
            <ShieldAlert className="w-6 h-6 text-red-500 animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white uppercase italic">Sentinel AI</h1>
            <p className="text-[10px] uppercase tracking-widest text-white/40 font-mono">Emergency Management Terminal</p>
          </div>
        </div>

        <div className="flex items-center gap-6 font-mono text-[11px] text-white/60">
          <div className="flex flex-col items-end">
            <span className="text-white/20 uppercase tracking-tighter">System Status</span>
            <span className="text-emerald-500 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              OPERATIONAL
            </span>
          </div>
          <div className="flex flex-col items-end border-l border-white/10 pl-6">
            <span className="text-white/20 uppercase tracking-tighter">Last Sync</span>
            <span>{lastUpdated}</span>
          </div>
        </div>
      </header>

      <main className="relative z-10 p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 max-w-7xl mx-auto">
        
        {/* Left Column: Sensors */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          <section className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-xs uppercase tracking-widest text-white/50 font-bold">
                <Activity className="w-4 h-4" /> Live Sensor Feed
              </h2>
              <button 
                onClick={() => setLastUpdated(new Date().toLocaleTimeString())}
                className="p-1 text-white/40 hover:text-white transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {nodes.map((node) => (
                <motion.div 
                  key={node.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`relative overflow-hidden group p-4 rounded-xl border bg-white/5 backdrop-blur-sm transition-all
                    ${node.temp > 50 ? 'border-red-500/30' : 'border-white/10'}`}
                >
                  <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
                    <Cpu className="w-12 h-12" />
                  </div>
                  
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <span className="text-[10px] font-mono text-white/30 uppercase tracking-widest leading-none block mb-1">
                        Node {node.id}
                      </span>
                      <h3 className="text-lg font-bold text-white tracking-tight leading-none italic">{node.location}</h3>
                    </div>
                    {node.temp > 50 && (
                      <AlertTriangle className="w-5 h-5 text-red-500 animate-bounce" />
                    )}
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center text-sm">
                      <span className="flex items-center gap-2 text-white/40"><Thermometer className="w-3.5 h-3.5" /> Temp</span>
                      <span className={`font-mono font-bold ${node.temp > 50 ? 'text-red-500' : 'text-white'}`}>
                        {node.temp}°C
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="flex items-center gap-2 text-white/40"><Bell className="w-3.5 h-3.5" /> Smoke</span>
                      <span className={`font-mono font-bold px-2 py-0.5 rounded text-[10px] uppercase
                        ${node.smoke === 'Detected' ? 'bg-red-500 text-white' : node.smoke === 'Low' ? 'bg-amber-500 text-black' : 'bg-white/10 text-white/40'}`}>
                        {node.smoke}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="flex items-center gap-2 text-white/40"><Wind className="w-3.5 h-3.5" /> Gas</span>
                      <span className={`font-mono font-bold ${node.gas > 100 ? 'text-red-500' : 'text-white'}`}>
                        {node.gas} PPM
                      </span>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-white/5">
                    <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min(node.temp, 100)}%` }}
                        className={`h-full ${node.temp > 50 ? 'bg-red-500' : 'bg-emerald-500'}`}
                      />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>

          <section className="mt-auto">
            <button
              onClick={analyzeEmergency}
              disabled={isAnalyzing}
              className={`w-full relative group overflow-hidden py-6 rounded-2xl border-2 transition-all flex items-center justify-center gap-3
                ${isAnalyzing 
                  ? 'bg-white/5 border-white/10 cursor-wait' 
                  : 'bg-red-600 hover:bg-red-700 border-red-500 shadow-[0_0_30px_rgba(239,68,68,0.2)] active:scale-[0.98]'
                }`}
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-6 h-6 animate-spin" />
                  <span className="text-xl font-bold italic uppercase tracking-wider">Analyzing Critical Data...</span>
                </>
              ) : (
                <>
                  <ShieldAlert className="w-7 h-7 group-hover:scale-110 transition-transform" />
                  <span className="text-2xl font-black italic uppercase tracking-tighter">Trigger AI Analysis</span>
                  <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </section>
        </div>

        {/* Right Column: AI Response */}
        <div className="lg:col-span-4 space-y-6">
          <AnimatePresence mode="wait">
            {!analysis ? (
              <motion.div 
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="h-full min-h-[400px] flex flex-col items-center justify-center p-8 rounded-2xl border border-dashed border-white/10 bg-white/2"
              >
                <div className="p-4 bg-white/5 rounded-full mb-6">
                  <Activity className="w-12 h-12 text-white/20" />
                </div>
                <h3 className="text-white/60 font-medium mb-2">No active incident analysis</h3>
                <p className="text-center text-sm text-white/30">Trigger analysis to process live sensor data and determine emergency status.</p>
              </motion.div>
            ) : (
              <motion.div 
                key="analysis"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                {/* Severity Card */}
                <div className={`p-6 rounded-2xl border ${getSeverityColor(analysis.severity)}`}>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-[10px] font-mono uppercase tracking-[0.2em] font-bold">Severity Level</span>
                    <span className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-widest border border-current">
                      {analysis.severity}
                    </span>
                  </div>
                  <h4 className="text-3xl font-black italic uppercase tracking-tighter leading-none mb-2">
                    {analysis.type}
                  </h4>
                  <div className="flex items-center gap-2 text-sm opacity-80">
                    <MapPin className="w-4 h-4 shrink-0" />
                    <span>Primary Impact: <strong className="font-bold">{analysis.affectedArea}</strong></span>
                  </div>
                </div>

                {/* Response Alert */}
                <div className="p-6 rounded-2xl bg-white/5 border border-white/10">
                  <h5 className="text-[10px] uppercase font-mono tracking-widest text-white/40 mb-3 flex items-center gap-2">
                    <Bell className="w-3 h-3" /> System Alert
                  </h5>
                  <p className="text-lg font-medium leading-relaxed italic text-white">
                    "{analysis.alertMessage}"
                  </p>
                </div>

                {/* Evacuation Route */}
                <div className="p-6 rounded-2xl bg-white/5 border border-white/10 overflow-hidden relative">
                  <div className="absolute top-0 right-0 p-8 opacity-5">
                    <LogOut className="w-32 h-32" />
                  </div>
                  <h5 className="text-[10px] uppercase font-mono tracking-widest text-white/40 mb-4">Protocol: Alpha-Exit</h5>
                  <div className="flex items-start gap-4">
                    <div className="mt-1 p-2 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                      <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                    </div>
                    <div>
                      <span className="text-xs text-white/40 uppercase font-bold tracking-tight">Safest Route</span>
                      <p className="text-white font-semibold flex items-center gap-2 mt-1">
                        {analysis.evacuationRoute}
                      </p>
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => setAnalysis(null)}
                  className="w-full py-3 px-4 rounded-xl text-xs font-bold uppercase tracking-widest text-white/40 hover:text-white hover:bg-white/5 transition-all border border-white/5"
                >
                  Clear Incident Matrix
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Footer Branding */}
      <footer className="relative z-10 border-t border-white/5 p-8 mt-12">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-white/20">
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-mono tracking-[0.3em] uppercase">Built with Gemini 3</span>
            <span className="w-1 h-1 rounded-full bg-white/20" />
            <span className="text-[10px] font-mono tracking-[0.3em] uppercase italic">Secure Node Integration</span>
          </div>
          <p className="text-[10px] font-mono uppercase tracking-[0.2em]">&copy; 2026 Sentinel Dynamics Corp. All Rights Reserved.</p>
        </div>
      </footer>
    </div>
  );
}
